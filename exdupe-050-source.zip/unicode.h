/*
 ********************************************************************************************************
 *                                                                                                      *
 *  eXdupe Archiver, copyright 2010 - 2013 by eXdupe.com. All rights reserved.                          *
 *                                                                                                      *
 *  eXdupe is traditional proprietary software, with most of the source code being available under      *
 *  restricted non-permissive terms:                                                                    *
 *                                                                                                      *
 *  You may modify eXdupe, and we encourage you to submit bugfixes or new features to us. However,      *
 *  redistribution of original or modified source code or binaries, or any derived work, is probitted.  *
 *                                                                                                      *
 *  EXDUPE IS NOT FREE. Use of original or modified eXdupe requires you to purchase a license (see      *
 *  http://www.exdupe.com/).                                                                            *
 *                                                                                                      *
 *  eXdupe contains 3'rd party source code files that carry their own original preamble terms and are   *
 *  not covered by above terms.                                                                         *
 *                                                                                                      *
 ********************************************************************************************************
*/


#ifndef UNICODE_H
#define UNICODE_H

#if defined(_WIN32) || defined(__WIN32__) || defined(_WIN64)
#define WINDOWS2
#endif

#ifdef WINDOWS2

	#define SPRINTF swprintf
	#define VSPRINTF vswprintf
	#define VFPRINTF vfwprintf
	#define FPRINTF fwprintf
	#define UNITXT(s) TEXT(s)
	#define STRING wstring
	#define CHR wchar_t
	#define REMOVE _wremove
	#define FOPEN _wfopen
	#define STRLEN wcslen
#else
	#define SPRINTF sprintf
	#define VSPRINTF vsprintf
	#define VFPRINTF vfprintf
	#define FPRINTF fprintf
	#define UNITXT(s) s
	#define STRING string
	#define CHR char
	#define REMOVE remove
	#define FOPEN fopen
	#define STRLEN strlen
#endif

#endif
